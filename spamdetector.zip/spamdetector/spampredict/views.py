from django.http import HttpResponse
from django.shortcuts import render 
import operator
import string
import joblib, os
PACKAGE_DIR = os.path.dirname(__file__)

def home(request):
    return render(request, 'home.html')

def count(request):
    fulltext = request.GET['fulltext']

    worddictionary = {}

    fulltext = fulltext.translate(str.maketrans('', '', string.punctuation))


    word_list = fulltext.split()

    print(type(word_list))
    #Load Vectorizer for Spam Detector
    spam_vectorizer = open(os.path.join(PACKAGE_DIR,"models/spam_vectorizer.pkl"),"rb")
    spam_cv = joblib.load(spam_vectorizer)

    spam_detector_model = open(os.path.join(PACKAGE_DIR,"models/spam_detector_nb_model.pkl"),"rb")
    spam_detector_clf = joblib.load(spam_detector_model)
    vectorized_data = spam_cv.transform(word_list).toarray()

    prediction = spam_detector_clf.predict(vectorized_data)
    result = []
    if prediction[0]==0:
        result = "Non-Spam"
    elif prediction[0]==1:
        result = "Spam"

    print("Result is :" , result)
    # word_list.append(result)
    # print(word_list[-1])

    for word in word_list:
        if word in worddictionary:
            worddictionary[word] += 1
        else:
            worddictionary[word] = 1

    sortedword = sorted(worddictionary.items(), key=operator.itemgetter(1), reverse=True)
    # print("Sorted wor : ",type(sortedword[-1]))
    # print(sortedword[-1])
    return render(request,'count.html',{'fulltext':result,'count':len(word_list),'sortedword':sortedword})


def about(request):
    return render(request, 'about.html')